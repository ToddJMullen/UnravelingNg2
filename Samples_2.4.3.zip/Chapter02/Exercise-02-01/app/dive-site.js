"use strict";
var DiveSite = (function () {
    function DiveSite() {
    }
    return DiveSite;
}());
DiveSite.FavoriteSites = [
    { id: 1, name: 'Shaab El Erg' },
    { id: 2, name: 'Abu Gotta Ramada' },
    { id: 3, name: 'El Arouk' },
    { id: 4, name: 'Small Giftun' }
];
exports.DiveSite = DiveSite;
//# sourceMappingURL=dive-site.js.map