export class DiveSite {
    id: number;
    name: string;

    static FavoriteSites: DiveSite[] = [
        { id: 1, name: 'Shaab El Erg'},
        { id: 2, name: 'Abu Gotta Ramada'},
        { id: 3, name: 'El Arouk'},
        { id: 4, name: 'Small Giftun'}
    ];
}