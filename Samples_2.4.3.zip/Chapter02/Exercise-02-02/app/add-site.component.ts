import {Component} from '@angular/core';

@Component({
  selector: 'add-site-view',
  templateUrl: 'app/add-site.template.html'
})
export class AddSiteComponent {
}